import matplotlib.pyplot as plt 
from collections import deque

import argparse

def sstring(string):
    if string not in ["int", "string", "huge", "slow"]:
        raise argparse.ArgumentTypeError("type not one of %s %s!" % ('int', 'string',
        'huge', 'slow'))
    return string

def ssort(string):
    if string not in ["+q", "+i", "+c", "+h", "+m", "+t", '-q', '-i', '-t', '-m', '-h',
            '-c', '-s', '+s']:
        raise argparse.ArgumentTypeError("type not one of sorts!")
    return string

parser = argparse.ArgumentParser(description='Draws plot of sorts and datatypes given via stdandard input.')
parser.add_argument('-t', '--type', dest='type', nargs='+', type=sstring, help='which type of data to show')
parser.add_argument('-s', '--sorts', dest='sorts', nargs='*', type=ssort,  help='which sorts to show (+s or -s) \
where s one of "q m c h i t s". If all -s, they are substracted from all. All is deafult')
args = parser.parse_args()


settings = [
        dict(c="b", edgecolors="b", marker="o"),
        dict(c="r", edgecolors="r", marker="x"),
        dict(c="g", edgecolors="g", marker="s"),
        dict(c="#FF8000", edgecolors="#FF8000", marker="d"),
        dict(c="#00FFFF", edgecolors="#00FFFF", marker="+"),
        dict(c="#FF00FF", edgecolors="#FF00FF", marker="p"),
        dict(c="#000000", edgecolors="#000000", marker="<"),
        dict(c="#CCCCCC", edgecolors="#CCCCCC", marker="^"),
]

if args.sorts == None: args.sorts = []
args.sorts = list(set(args.sorts)) # remove duplicates
sorts = set(["q", "i", "c", "h", "m", "t", "s"])
for i in args.sorts:
    if i[0] == '+':
        sorts = set(); break

minus = set()
plus = set()
for i in args.sorts:
    if i[0] == '-': minus.add(i[1])
    elif i[0] == '+': plus.add(i[1])

sorts |= plus
sorts -= minus


leg = []; j = 0;
x = [[] for i in range(len(sorts))]
y = [[] for i in range(len(sorts))]
while True:
    a = raw_input();
    if a == "Done!": break
    if a[:4] == "ln: ":
        M = int(a[4:])
        k = 0
        for i in range(7):
            a, b, c, d = raw_input(), raw_input(), raw_input(), raw_input()
            if a[0] in sorts:
                if "int" in args.type:
                    x[k].append(M)
                    y[k].append(float(a[4:]))
                if "string" in args.type:
                    x[k].append(M)
                    y[k].append(float(b[4:]))
                if "huge" in args.type:
                    x[k].append(M)
                    y[k].append(float(c[4:]))
                if "slow" in args.type:
                    x[k].append(M)
                    y[k].append(float(d[4:]))
                if j == 0:
                    leg.append(a[0])
                k += 1 
    j+=1
xmin = min(min(f) for f in x);

plots = [plt.scatter(x[i], y[i], label=leg[i], **settings[i]) for i in range(len(sorts)) ]
xmin = min(min(f) for f in x);
xmax = max(max(f) for f in x);
ymin = min(min(f) for f in y);
ymax = max(max(f) for f in y);
plt.axis([xmin, xmax, ymin, ymax])

#leg = deque(leg)
#leg.rotate(-1)

plt.legend(plots, leg, "upper left")
plt.title(' '.join(args.type))
#plt.legend(leg, "center left")
plt.show() 
