from sys import argv

f = open(argv[1], "r").read()
c = ''
for i in f:
    if i in "{}":
        c += i
print c
print c.count("{")
print c.count("}")
print c.count("{") == c.count("}")
